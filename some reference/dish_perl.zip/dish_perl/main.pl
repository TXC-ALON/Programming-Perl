#!/usr/bin/perl

BEGIN{push @INC, "D:/wks_perl/dish_perl/util";}
BEGIN{push @INC, "D:/wks_perl/dish_perl/obj";}

use utf8;
use warnings;
use strict;


binmode(STDOUT,":encoding(gbk)");
#标准输出使用gbk作为编码格式，也可以把gbk改为gb2312
binmode(STDIN,":encoding(gbk)");
binmode(STDERR,":encoding(gbk)");


use Global_setting;
use Reg_util;
use File_util;
use Common_util;



sub main{
	my @orders=File_util->read_file("./doc/order.txt");

	# 初始化 log
	File_util->cratre_overwrite_file("./doc/res.txt","");

	my $size = @orders;
	my $cur_date="";
	my %data=();

	for (my $i=0;$i<$size;$i++){
		my $line=$orders[$i];
		$line=Reg_util->remove_end_space($line);

		File_util->append_file("./doc/res.txt",$line."\n");

		my $date=Reg_util->get_date($line);
		my $customer=Reg_util->get_customr_name($line);
		File_util->append_file("./doc/res.txt","customer:$customer\n");
		if($date cmp  $cur_date){
			$cur_date=$date;
			Global_setting->reset_max_num();
		}
		if(!exists($data{$date})){
			 $data{$date}=();
		}

		my @order_array=Common_util->get_order_array($line);

		$data{$date}{$customer}=\@order_array;
	}

	Common_util->report(%data);

}



&main();

