package Global_setting;
use utf8;
use warnings;
use strict;


# 汤的种类
use constant { 
    VEGETABLE_SOUP   => 'vegetable_soup',
    BROTH   => 'broth',
};

# 面包的种类
use constant {
    WHITE_BREAD => 'white_bread',
    WHEAT_BREAD => 'wheat_bread',
};

# 每日最大供应量
use constant {
    MAX_VEG_SOUP_PER_DAY   => 5,
    MAX_BROTH_PER_DAY   => 5,
};


# 全局变量 当前供应量

$LB::veg_soup_price=4;
$LB::broth_price=9;

$LB::white_bread_price=3;
$LB::wheat_bread_price=5;


our $cur_broth_num=0;
our $cur_veg_soup_num=0;


our $white_bread_discount_num=2;


sub reset_max_num {
	# 清除供应量
	$cur_broth_num =0;
	$cur_veg_soup_num=0;

	# 每天涨价1元
	$LB::veg_soup_price+=1;
	$LB::broth_price+=1;
	$LB::white_bread_price+=1;
	$LB::wheat_bread_price+=1;
}


1;