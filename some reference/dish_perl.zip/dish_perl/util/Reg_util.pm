
package Reg_util;
use utf8;
use warnings;
use strict;


sub contain {
	my ($class,$word,$target,$ignore_cap)=@_;
	$_=$word;
	if($ignore_cap){
		return 1 if /$target/i;
	}else{
		return 1 if /$target/;
	}
	0;
}

sub contain_space {
	my ($class,$word)=@_;
	$_=$word;
	return 1 if /\p{Space}/;
	0;
}

sub contain_words {
	# 包含数字或符号
	my ($class,$word)=@_;
	$_=$word;
	return 1 if /\w/;
	0;
}


sub is_digit{
	my ($class,$num)=@_;
	my $reg1 = qr/^-?\d+(\.\d+)?$/;
	my $reg2 = qr/^-?0(\d+)?$/;
	return 1 if ( $num =~ $reg1 && $num !~ $reg2 );    
	0;
}


sub contain_digit {
	my ($class,$word,$target)=@_;
	$_=$word;
	# (?# return 1 if /\p{Digit}/;)
	return 1 if /\d/;
	0;
}


sub to_lower { 
	# 转成小写
	my ($class,$word)=@_;
	$word =~ tr/A-Z/a-z/;
	$word;
}

sub to_cap {
	# 转成大写
	my ($class,$word)=@_;
	$word =~ tr/a-z/A-Z/;
	$word;
}



sub replace {
	# 替换
	my ($class,$word,$tar,$replace,$ignore_cap) = @_;
	if($ignore_cap==1){
		$word =~ s/$tar/$replace/i;
	}else{
		$word =~ s/$tar/$replace/;
	}
	$word;
}


sub get_numbers {
	# 找出数字并存放在一个数组里返回
	my ($class,$str)=@_;
	my @d = $str =~/[\-\d]?[\d]*[\.]?[\d]+/g;
	@d;
}



sub get_first_match {
	# 截取匹配后的第一个字符
	my ($class,$str,$criteria)=@_;
	my @d =$str =~/$criteria[\s]+(.*?)[\s;,]/;
	$d[0];
}

sub get_customr_name {
	my ($class,$str)=@_;
	$str = get_first_match($class,$str,"customer");
	$str = remove_end_space($class,$str);
	$str = remove_begin_space($class,$str);
}

sub get_date {
	# 截取匹配后的第一个字符2021-05-01
	my ($class,$str)=@_;
	# @d = $str =~/[\d]+[\-\d]+[\-\d]+/g;
	my @d = $str =~/[\d]+[\-][\d]+[\-][\d]+/g;
	$d[0];
}



sub remove_end_space {
	my ($class,$str)=@_;
	$str =~ s/[\r\n\s]$//; 
	$str;
}

sub remove_begin_space {
	my ($class,$str)=@_;
	$str =~ s/^[\s\t]+//; 
	$str;
}

1;