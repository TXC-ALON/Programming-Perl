package Common_util;

use utf8;
use warnings;
use strict;



use Reg_util;
use Global_setting;
use Soup;
use Bread;

sub get_order_array {
	my($class,$line)=@_;
	my @res;

	my @line_arr=split /,/,$line;
	foreach my $line_item (@line_arr){
		my @nums=Reg_util->get_numbers($line_item);

		if(Reg_util->contain($line_item,Global_setting::VEGETABLE_SOUP,1)){

			my $object =new Soup( Global_setting::VEGETABLE_SOUP,$LB::veg_soup_price,0);

			$object->order($nums[0]);
			if($object->{_cups}>0)
			{
				push @res,$object;
			}

		}elsif(Reg_util->contain($line_item,Global_setting::BROTH,1)){
			my $object =new Soup();
			$object->set_name(Global_setting::BROTH);
			$object->set_price($LB::broth_price);


			$object->order($nums[0]);

			if($object->{_cups}>0)
			{
				push @res,$object;
			}

		}elsif(Reg_util->contain($line_item,Global_setting::WHITE_BREAD,1)){
			
			my $object =new Bread();
			$object->{_name}=Global_setting::WHITE_BREAD;
			$object->{_price}=$LB::white_bread_price;


			$object->order($nums[0]);
			if($object->{_units}>0)
			{
				push @res,$object;
			}

		}elsif(Reg_util->contain($line_item,Global_setting::WHEAT_BREAD,1)){
			my $object =new Bread();
			$object->{_name}=Global_setting::WHEAT_BREAD;
			$object->{_price}=$LB::wheat_bread_price;
			$object->order($nums[0]);
			if($object->{_units}>0)
			{
				push @res,$object;
			}
		}else{
			;
		}
		

	}

	# log
	for my $item (@res){
		$item->print_self();
	}
	File_util->append_file("./doc/res.txt","----------------------------------------------------\n");
	

	return @res;
}


sub report {
	my($class,%data)=@_;

	my %sum_by_date=();
	my %sum_by_customer=();
	my %sum_by_name=();

	for my $date (keys %data){
		my %tmp=%{$data{$date}};
		for my $customer (keys  %tmp){
			my @order=@{$data{$date}{$customer}};
			foreach my $item (@order){


				# 取出数据
				my $name=$item->{_name};
				my $price=$item->{_price};
				my $num;
				if(($name eq Global_setting::VEGETABLE_SOUP) || ($name eq Global_setting::BROTH)){
					$num = $item->{_cups};
				}else{
					$num = $item->{_units};
				}

				my $money=$num*$price;


				if(!exists($sum_by_date{$date})){
					$sum_by_date{$date}=$money;
				}else{
					$sum_by_date{$date}+=$money;
				}

				if(!exists($sum_by_customer{$customer})){
					$sum_by_customer{$customer}=$money;
				}else{
					$sum_by_customer{$customer}+=$money;
				}

				if(!exists($sum_by_name{$name})){
					$sum_by_name{$name}=$money;
				}else{
					$sum_by_name{$name}+=$money;
				}
			}
		}
	}

	File_util->append_file_and_print("./doc/res.txt","=====Final SUM beg========================================\n");

	my $sum=0;
	my @date_list= keys %sum_by_date;
	@date_list = sort(@date_list);
	foreach my $date (@date_list){
		my $money=$sum_by_date{$date};
		
		File_util->append_file_and_print("./doc/res.txt","date $date sum:".$money."\n");
		
		$sum+=$money;
	}

	File_util->append_file_and_print("./doc/res.txt","sum:".$sum."\n");
	File_util->append_file_and_print("./doc/res.txt","-----------------------------------------------------------\n");

	$sum=0;
	while (my($customer,$money) = each(%sum_by_customer)){ 
		File_util->append_file_and_print("./doc/res.txt","customer $customer sum:".$money."\n");
		$sum+=$money;
	}

	File_util->append_file_and_print("./doc/res.txt","sum:".$sum."\n");

	File_util->append_file_and_print("./doc/res.txt","-----------------------------------------------------------\n");
	
	$sum=0;
	while (my($name,$money) = each(%sum_by_name)){ 
		File_util->append_file_and_print("./doc/res.txt","name $name sum:".$money."\n");
		$sum+=$money;
	}

	File_util->append_file_and_print("./doc/res.txt","sum:".$sum."\n");
	File_util->append_file_and_print("./doc/res.txt","=====Final SUM end========================================\n");
}

1;