package File_util;
use utf8;
use warnings;
use strict;

use Reg_util;

sub read_file {
	my($class,$file_path)=@_;
  	open(MYFILE,$file_path)||die "err: $!\n";
	# @array = <MYFILE>;
	my @array;
	while($_ = <MYFILE>){
		if(Reg_util->contain_words($_)==1){
			$_=Reg_util->remove_end_space($_);
			$_ =Reg_util->remove_begin_space($_);
			push @array,$_;
		}
	}

	close MYFILE;
	return @array;
}


sub append_file {
	my($class,$file_path,$str)=@_;
  	open(MYFILE,">>".$file_path)||die "err: $!\n";
  	print MYFILE $str;
	close MYFILE;
}

sub append_file_and_print {
	my($class,$file_path,$str)=@_;
	append_file($class,$file_path,$str);
	print $str;
}


sub cratre_overwrite_file {
	my($class,$file_path,$str)=@_;
  	open(MYFILE,">".$file_path)||die "err: $!\n";
  	print MYFILE $str;
	close MYFILE;
}


sub readable {
	my($class,$file_path)=@_;
	return 1 if(-r $file_path);
	0;
}


sub writeable {
	my($class,$file_path)=@_;
	return 1 if(-w $file_path);
	0;
}

sub is_exists {
	my($class,$file_path)=@_;
	return 1 if(-e $file_path);
	0;
}

sub is_empty {
	my($class,$file_path)=@_;
	return 1 if(-z $file_path);
	0;
}


sub file_size {
	my($class,$file_path)=@_;
	return (-s $file_path);
}



sub is_file {
	my($class,$file_path)=@_;
	return 1 if(-f $file_path);
	0;
}


sub is_dir {
	my($class,$file_path)=@_;
	return 1 if(-d $file_path);
	0;
}

sub is_text_file {
	my($class,$file_path)=@_;
	return 1 if(-T $file_path);
	0;
}

sub is_binary_file {
	my($class,$file_path)=@_;
	return 1 if(-B $file_path);
	0;
}

sub write_file {
	my($class,$file_path,$str)=@_;
	if(is_exists("",$file_path)){
		append_file("",$file_path,$str);
	}else{
		cratre_overwrite_file("",$file_path,$str);
	}
}

1;